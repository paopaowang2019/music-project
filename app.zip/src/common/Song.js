export default class Song {
  constructor ({id, name, album, author, alPicUrl, img}) {
    this.id = id
  }
}
