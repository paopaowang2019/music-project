export const presetPlaylist = [
  {id: 2774972642, name: '古风中国风（精选）往事散云烟'},
  {id: 2163404529, name: '听了心情会变好的欢快古风小调'},
  {id: 2269451208, name: '最火古风100首'},
  {id: 907446361, name: '「古风」这些古风歌词，惊艳了时光'},
  {id: 2122703724, name: '仙剑奇侠传一 仙剑奇侠传三 电视剧原声带'},
  {id: 156720466, name: '欢快旋律清新女声萦绕快乐气氛'}
]

export const presetSingers = [
  {id: 6452, name: '周杰伦'},
  {id: 12025552, name: '双笙'},
  {id: 188565, name: '银临'},
  {id: 8103, name: '花粥'},
  {id: 14312549, name: '王贰浪'},
  {id: 9270, name: '萨顶顶'}
]

export const myListId = 123456

export const vipUrl = 'https://vip.bljiex.com/?v='

export const YKUrl = '/vpi/GetYKData?page='

export const TXUrl = '/vpi/GetTXData?page='

export const QYUrl = '/vpi/GetQYData?page='
