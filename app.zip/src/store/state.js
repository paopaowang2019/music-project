export default {
  playing: false,
  currentIndex: 0,
  songList: []
}
