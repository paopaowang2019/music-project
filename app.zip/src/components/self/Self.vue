<template>
  <div class="self">
    Self
  </div>
</template>

<script>
export default {
  name: 'self',
  data () {
    return {
      data: ''
    }
  },
  computed: {},
  methods: {},
  watch: {},
  created: function () {},
  mounted: function () {}
}
</script>

<style scoped>

</style>
