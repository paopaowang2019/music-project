<template>
  <div class="shop">
    shop
  </div>
</template>

<script>
export default {
  name: 'shop',
  data () {
    return {
      data: '',
      ratio: 0.25
    }
  },
  components: {
  },
  computed: {},
  methods: {},
  watch: {},
  created: function () {},
  mounted: function () {}
}
</script>

<style scoped>

</style>
