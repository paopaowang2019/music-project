import Vue from 'vue'

export default new Vue()
